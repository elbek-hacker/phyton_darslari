    habar = """
    Amallardan birini tanlang:
        1. Mahsulotni ko'rish
        2. Mahsulot qidirish
        3. Mahsulotni filtrlash
            1. Meva
            2. Telefeon
        2. Savatchaga qo'shish olish
        3. Savatchani ko'rish (Har biri va Jami mahsulot summasi)
        4. Savatchadan o'chirish

        5. Profil
        0. Chiqish
        """