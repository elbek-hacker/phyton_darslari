for i in range(1, 501, 1):
    print(i, end = " ")