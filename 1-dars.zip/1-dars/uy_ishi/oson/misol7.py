#'a' dan 'z' gacha bo'lgan harflarni ekranga chiqarish
for i in range (ord("a"), ord("z")+1, 1):
    print(chr(i), end = " ")