for i in range(250, 0, -1):
    print(i, end = " ")