son = int(input("son kiriting: "))
i = 1
while i*i < son:
    i += 1

print(i)