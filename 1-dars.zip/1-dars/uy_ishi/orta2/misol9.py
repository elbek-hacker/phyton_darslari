son = int(input("son kiriting: "))
for i in range(0, son, 1):
    for j in range(0, i+1, 1):
        print(j + 1, end = "")
    print("")