son = int(input("son kiriting: "))
print(son, "karra jadvali:")
for i in range (1, 11, 1):
    print(f"{son} * {i} = {son * i}")