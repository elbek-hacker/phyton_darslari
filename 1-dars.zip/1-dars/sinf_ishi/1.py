matn = "bugun 1 dars lekin 3 ta dars otdik"

for i in range(0, len(matn)):
    #print(matn[i], end = '')
    print(chr(ord(matn[i]) + 1), end='' )