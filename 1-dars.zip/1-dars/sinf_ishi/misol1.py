a = 49
i = 1
while True:
    if i * i > a:
        print(i)
        break
    i = i + 1