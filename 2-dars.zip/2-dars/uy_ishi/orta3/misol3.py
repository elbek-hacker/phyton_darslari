a, b = int(input("son 1: ")), int(input("son 2: "))
yig = 0
for i in range (a, b+1):
    yig += i
print("yigindi: ", yig)