son = int(input("son: "))
for i in range (1, son*2 + 1):
    print(i, end = " ")