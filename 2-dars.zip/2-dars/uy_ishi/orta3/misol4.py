N = int(input("son: "))
yig = 1
for i in range (1, N + 1):
    yig *= i
print(f"{N} Faktorial = {yig}")