a, b = int(input("son 1: ")), int(input("son 2: "))

print(a ** b)