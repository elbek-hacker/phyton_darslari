a = int(input("son: "))
for i in range (1, a//2 + 1):
    if i*i == a:
        print(i)
        break