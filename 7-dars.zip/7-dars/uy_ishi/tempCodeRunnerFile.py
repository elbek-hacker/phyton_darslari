
# m3 = Mahsulot("Non", 200, 3000)