set1.discard(100)
# print(set1)