n = int(input("son kiriting: "))
dic = {}
for i in range (1, n):
    dic[i] = i*i
print(dic)