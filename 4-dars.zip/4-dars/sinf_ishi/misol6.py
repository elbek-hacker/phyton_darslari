numbers = {15, 8, 25, 3, 10}

a = max(numbers)
print(a)