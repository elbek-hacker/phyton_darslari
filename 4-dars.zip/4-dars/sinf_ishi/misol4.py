set1 = {1, 2, 3, 4}
set2 = {3, 4, 5, 6}

print(set1.symmetric_difference(set2))