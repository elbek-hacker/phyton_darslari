
for j in range (1, 11):
    for i in range (1, 6):
        print(f"{i} * {j} = {j * i}", end = "\t")
    print()
print()
for j in range (1, 11):
    for i in range (6, 11):
        print(f"{i} * {j} = {j * i}", end = "\t")
    print()