soz = input ("so'z kiriting:")
new_lst = []
for i in range (len(soz)):
    new_lst.append(soz[i])

print(new_lst)