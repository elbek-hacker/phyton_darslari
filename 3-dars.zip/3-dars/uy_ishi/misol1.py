a, b = int(input("son kiriting: ")),  int(input("son kiriting: "))

for i in range (a, b):
    if i % 2 == 0:
        print(i, end = " ")