tuple = [('item1', '12.20'), ('item2', '15.10'), ('item3', '24.5')]
tuple.reverse()
print(tuple)