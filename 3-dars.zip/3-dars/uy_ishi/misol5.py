matn = input("soz kiriting: ")
sozlar = matn.split()
sozlar.sort()
print(' '.join(sozlar))