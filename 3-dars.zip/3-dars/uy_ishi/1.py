user_input = input("Enter something: ")

if "o'" in user_input:
    print("You entered the Uzbek letter o'!")
else:
    print("yo'q")