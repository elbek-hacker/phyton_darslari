nt(input("nechta son kiritasiz: "))
# list = []
# for i in range (n):
#     son = int(input(f"{i+1} sonni kiriting: "))
#     list.append(son)