lst = [1, 2, 3,4, 5, 6, 7, 89]

print(list(filter(lambda x: x % 2 == 1, lst)))