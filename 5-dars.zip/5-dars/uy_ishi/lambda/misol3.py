tartibla = lambda t: sorted(t, key = lambda x: x[1])

list = [(2, 5), (1, 2), (4, 4), (2, 3), (2, 1)]
print(tartibla(list))