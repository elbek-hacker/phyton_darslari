kopaytir = lambda a: a * 3

print(kopaytir(5))