kopaytir = lambda a: a * 2

print(kopaytir(5))