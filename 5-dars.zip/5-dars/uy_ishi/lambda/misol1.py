x = lambda a, b: a if a > b else b
print(x(9, 3))