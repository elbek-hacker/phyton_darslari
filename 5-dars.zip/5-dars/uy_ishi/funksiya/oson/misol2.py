def raqamlar_yigindisi(royxat, n):
    skjdafb wihdfiq qiwhfi
    i don't get the question