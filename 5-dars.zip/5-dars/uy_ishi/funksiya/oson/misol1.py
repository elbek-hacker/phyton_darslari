def tortburchak_yasa(n, m):
    for i in (1, n):
        print("*" * m)

tortburchak_yasa(3, 5)