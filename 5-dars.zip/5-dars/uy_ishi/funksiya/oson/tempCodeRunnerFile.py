 = ["Jon", "Jeyms", "Piter", "Tony"]
# list2 