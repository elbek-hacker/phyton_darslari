sozlar = ["olma", "uzum", "banan", "shaftoli"]

natija = map(lambda a: len(a), sozlar)

print(list(natija))