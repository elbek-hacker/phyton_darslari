lst = ["molas", "lug", "apmal", "hsoyuq"]

natija = map(lambda a: a[::-1], lst)

print(list(natija))