lst = ["olma", "uzum", "banan", "shaftoli"]

natija = filter(lambda a: len(a) == 5, lst)

print(list(natija))