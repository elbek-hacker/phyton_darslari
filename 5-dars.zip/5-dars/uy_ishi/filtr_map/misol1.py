sonlar = [1, 2, 3]
natija = map(lambda a: a* 3, sonlar)
print(list(natija))