lst = [1,4,2,3,5]
natija = map(lambda a: a ** 2, lst)

print(list(natija))