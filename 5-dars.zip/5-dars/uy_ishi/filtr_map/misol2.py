lst1 = [1, 2, 3]
lst2 = [4, 5, 6]
natija = map(lambda a, b: a + b, lst1, lst2)
print(list(natija))