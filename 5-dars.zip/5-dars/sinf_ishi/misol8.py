kattasi = lambda a,b: a if a > b else b
print(kattasi(4,19))
print(kattasi(40,19))
