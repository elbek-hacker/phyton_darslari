def raqamlar_yigindisi(royxat, n):
    # sum = 0
    # for i in range(n):
    #     sum += royxat[i]
    

    # return sum
    return sum(royxat[0:n])



n = raqamlar_yigindisi([3,4,5], 2)
print(n)
