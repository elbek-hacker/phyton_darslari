ortacha = lambda lst: sum(lst) // len(lst)


print(ortacha([1, 2, 3, 4,5]))