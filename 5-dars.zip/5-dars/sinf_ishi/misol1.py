N = int(input("son kiriting: "))

dict = {}

for i in range (1, N):
    dict[i] = i * i
print(dict)